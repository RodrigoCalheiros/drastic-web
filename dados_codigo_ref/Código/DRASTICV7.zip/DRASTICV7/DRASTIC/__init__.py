def classFactory(iface):
    from .DrasticToolbar import DrasticToolbar
    return DrasticToolbar(iface)